/*
 * SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note
 *
 * Copyright (C) 2020 Philippe Gerum  <rpm@xenomai.org>
 */

#ifndef _EVL_UAPI_NET_SCHED_H
#define _EVL_UAPI_NET_SCHED_H

#endif /* !_EVL_UAPI_NET_SCHED_H */
