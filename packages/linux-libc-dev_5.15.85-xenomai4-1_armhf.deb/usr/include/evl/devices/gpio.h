/*
 * SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note
 */

#ifndef _EVL_UAPI_DEVICES_GPIO_H
#define _EVL_UAPI_DEVICES_GPIO_H

#define GPIOHANDLE_REQUEST_OOB		(1UL << 5)

#endif /* !_EVL_UAPI_DEVICES_GPIO_H */
