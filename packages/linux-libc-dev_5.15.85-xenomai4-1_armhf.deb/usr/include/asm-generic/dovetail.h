/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef __ASM_GENERIC_DOVETAIL_H
#define __ASM_GENERIC_DOVETAIL_H

#define __OOB_SYSCALL_BIT	0x10000000

#endif /* !__ASM_GENERIC_DOVETAIL_H */
